# Wrath Tactics 当前配置说明

这份说明对应 2026-09-27 改完之后的 8 条规则。一键 Buff 在 `BuffIt-OneClickBuff.md`。

快照来自游戏关闭后的本机文件。`tactics-current-config.json` 是副本。游戏读取的是：

```
D:\SteamLibrary\steamapps\common\Pathfinder Second Adventure\Mods\WrathTactics\UserSettings\tactics-7ea3d466491c4249aec2742271c2e71a.json
```

- 模组：Wrath Tactics 1.32.1，作者 Gh05d
- 安装文件版本：`1.32.1+95dc9d7c5f57917e9b85f1a9eee537cf2b626fed`
- 文件名里的 `7ea3d466491c4249aec2742271c2e71a` 是 FaN 这份存档的 GameId
- 游戏内打开面板：Ctrl+T
- 同目录 `Presets` 是预设库。当前规则的 `PresetId` 都是 null，运行的是本文件正文
- 改之前的备份：同目录 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1310`

## 执行顺序

每一拍先跑 `GlobalRules`，再跑该角色的 `CharacterRules`。全局规则优先级更高。

当前 `GlobalRules` 是空数组。只有 FaN 有规则。名单里靠前的规则先判断。一条规则占住标准动作后，同一拍里更靠后的规则不再占同一个动作。

`TacticsEnabled` 为 true 才会评估。当前 8 个单位都是 true，但只有 FaN 有 `CharacterRules`。

## 顶层字段

| 字段 | 当前值 | 含义 |
|---|---|---|
| `GlobalRules` | `[]` | 全局规则。当前没有 |
| `CharacterRules` | 只有 FaN 一个键 | 键是单位编号，值是规则数组 |
| `TacticsEnabled` | 8 个单位都是 true | 是否启用战术 |
| `ShowPortraitToggles` | true | 头像上显示战术开关 |
| `TickIntervalSeconds` | 3.0 | 战斗中检查间隔，秒 |
| `OutOfCombatTickIntervalSeconds` | 2.0 | 非战斗检查间隔，秒 |
| `DebugLogging` | false | 不写调试日志 |
| `RecentBuffGuids` | `[]` | 空 |

角色规则的键必须等于 `Unit.UniqueId`。FaN 用完整 GUID。其他单位用 4 位短编号。短编号不能猜成某个队友的显示名。

## 单位

和一键 Buff 是同一套编号。

| 单位编号 | 存档里能确定的事实 |
|---|---|
| `2c002cb0-2987-4e37-a575-eb5cdd155850` | FaN。半血裔、法师 20、噬血法师变体、巫妖神话职业 8 级、神话起始职业 2 级，合计神话 10 阶。有不死生物类型。负能量治疗他，正能量伤害他 |
| `56A0` | 吟游诗人，带神话同伴等级。有不死生物类型 |
| `57A6` | 战斗祭司，带神话同伴等级。有不死生物类型 |
| `2805` | 有法术书。有不死生物类型。职业名没有从存档文本里直接读出 |
| `5568` | 有不死生物类型 |
| `5611` | 有不死生物类型 |
| `5728` | 有不死生物类型 |
| `55FD` | 这 8 个编号里唯一没有不死生物类型。战术界面有一个 Horse 位，这个编号按那匹马来用 |

界面上还有 Ciar、Queen Galfrey、Delamere、Staunton Vhane、Kestoglyr、Skeletal Marksman。存档不把这些显示名写在短编号旁边。

## 一条规则的结构

```json
{
  "Id": "规则自己的 id",
  "Name": "界面上的名字",
  "Enabled": true,
  "CooldownRounds": 1,
  "ConditionGroups": [
    {
      "Conditions": [
        {
          "Subject": 0,
          "Property": 0,
          "Operator": 0,
          "CountOperator": 4,
          "Value": "25",
          "Value2": ""
        }
      ]
    }
  ],
  "Action": {
    "Type": 0,
    "AbilityId": "法术键",
    "FallbackAbilityIds": [],
    "HealMode": 0,
    "HealSources": 7,
    "HealEnergy": 0,
    "Sources": 1,
    "SplashMode": 0,
    "ToggleMode": 0,
    "MetamagicRod": null,
    "WeaponSetIndex": 0,
    "MoveWithin": 0
  },
  "Target": { "Type": 0, "Filter": "" },
  "PresetId": null,
  "PackId": null
}
```

- `ConditionGroups` 之间是或。同一个 group 里的 `Conditions` 是并且。
- `PresetId` 为 null 时，用本文件里的条件和动作。填了预设 id 就会改用预设正文。
- `CooldownRounds`：成功施放后的冷却回合。
- `Enabled` 为 false 时规则留在文件里，但不会执行。Hungry Flesh 现在是这样。

## 法术键

`AbilityId` 不是裸 GUID。格式：

```
guid[@L等级][>V变体guid][~A动作类型][#超魔掩码]
```

例子：`1098095d7a88c6747aee67f8d449fa06@L5` 是 5 环 Deny Death。

只写 32 位 GUID、不写 `@L等级` 时，下拉框对不上，界面会显示成 `[L0] Acid Splash`。

`HasBuff` 的 `Value` 是增益蓝图编号，不是法术编号。

Buff It 用带连字符的 GUID。Wrath Tactics 用不带连字符的 32 位小写十六进制。去掉连字符就是同一个编号。

## 条件主体 Subject

| 数字 | 名字 |
|---|---|
| 0 | Self |
| 1 | Ally |
| 2 | AllyCount |
| 3 | Enemy |
| 4 | EnemyCount |
| 5 | Combat |
| 6 | EnemyBiggestThreat |
| 7 | EnemyLowestThreat |
| 8 | EnemyHighestHp |
| 9 | EnemyLowestHp |
| 10 | EnemyLowestAC |
| 11 | EnemyHighestAC |
| 12 | EnemyLowestFort |
| 13 | EnemyHighestFort |
| 14 | EnemyLowestReflex |
| 15 | EnemyHighestReflex |
| 16 | EnemyLowestWill |
| 17 | EnemyHighestWill |
| 18 | EnemyHighestHD |
| 19 | EnemyLowestHD |
| 20 | AllyByName |
| 21 | EnemyNearest |

人数条件用 `EnemyCount`（4）或 `AllyCount`（2）。`CountOperator` 4 是大于等于。`Value2` 为 `"2"` 表示人数大于等于 2。

## 条件属性 Property

| 数字 | 名字 |
|---|---|
| 0 | HpPercent |
| 1 | AC |
| 2 | HasBuff |
| 3 | HasCondition |
| 4 | SpellSlotsAtLevel |
| 5 | SpellSlotsAboveLevel |
| 6 | Resource |
| 7 | CreatureType |
| 8 | CombatRounds |
| 9 | IsDead |
| 10 | SaveFortitude |
| 11 | SaveReflex |
| 12 | SaveWill |
| 13 | Alignment |
| 14 | IsInCombat |
| 15 | HitDice |
| 16 | SpellDCMinusSave |
| 17 | HasClass |
| 18 | WithinRange |
| 19 | ABMinusAC |
| 20 | IsTargetingSelf |
| 21 | IsTargetingAlly |
| 22 | IsTargetedByAlly |
| 23 | IsTargetedByEnemy |
| 24 | IsSummon |
| 25 | EnemyHDMinusPartyLevel |
| 26 | IsPet |
| 27 | IsFlanked |
| 28 | AdjacentEnemyCount |
| 29 | HasDescriptorEffect |
| 30 | ImmuneToEnergy |
| 31 | AbilityDamage |
| 32 | NegativeLevels |
| 33 | HpFlat |
| 34 | WieldsRangedWeapon |

`HasBuff` 配合 `Operator` 3 表示没有这个增益。

`SpellDCMinusSave`（16）在 1.32.1 的提交 `95dc9d7` 里由 `ComputeDCMinusSave` 计算。它读取当前这条规则的 `Action.AbilityId`，从该法术蓝图的豁免类型算出 `法术 DC − 对应豁免`。不写死意志或强韧。法术没有豁免，或当前找不到这个法术时，结果无效，条件不成立。它不看 `FallbackAbilityIds`。

## 比较符

| 数字 | 名字 |
|---|---|
| 0 | LessThan |
| 1 | GreaterThan |
| 2 | Equal |
| 3 | NotEqual |
| 4 | GreaterOrEqual |
| 5 | LessOrEqual |

## 动作 Type

| 数字 | 名字 |
|---|---|
| 0 | CastSpell |
| 1 | CastAbility |
| 2 | UseItem |
| 3 | ToggleActivatable |
| 4 | AttackTarget |
| 5 | Heal |
| 6 | DoNothing |
| 7 | ThrowSplash |
| 8 | SwitchWeaponSet |
| 9 | MoveToTarget |

`Sources` 和 `HealSources`：1 只用自己的法术，2 卷轴，4 药水，7 全部。当前攻击和治疗规则都是 1。

`HealEnergy`：0 Auto，1 Positive，2 Negative。FaN 的自疗是 2。`HealMode`：0 Any，1 Strongest，2 Weakest。自疗是 1。

## 目标 Type

| 数字 | 名字 |
|---|---|
| 0 | Self |
| 4 | EnemyNearest |
| 15 | EnemyHighestThreat |
| 17 | ConditionTarget |
| 21 | PointAtConditionTarget |
| 23 | EnemyMostEnemyNeighbors |

完整枚举还有 1–3、5–14、16、18–20、22、24，分别是队友血量、各项豁免、生物类型、HD、自身落点和指定队友。当前启用的规则用 0、17、21。Hungry Flesh 仍是 21，但是禁用。没有规则再用 15。

`PointAtConditionTarget`（21）落在本条条件匹配到的单位旁边约 1.5 米、朝向施法者的位置。

目标 15 会重新选取全场威胁最高的敌人，和条件筛中的人可能不是同一个。2026-09-27 两条即死术已改为目标 17（ConditionTarget）。谁通过血量和 DC−豁免，法术就打谁。

## 选择性超魔

本机 `cheatdata.json` 里有专长 `SelectiveSpellFeat`，编号 `85f3340093d144dd944fff9a9adfd2f2`。FaN 的单位上挂着这个专长。选择性法术可以让范围法术避开指定生物。

这份存档的 `party.json` 和 `player.json` 里没有这三根杖：

- `MetamagicRodLesserSelective` `b1728ccecbb54c939575dfeb866c1e9f`
- `MetamagicRodNormalSelective` `c256be263e99480da5b7cf2a1da1ef17`
- `MetamagicRodGreaterSelective` `5db66b14642642eaa1c623ed0daa5813`

Wrath Tactics 的 `MetamagicRod` 是给已装备的超魔杖用的。有专长不会自动给一条规则加上选择性。当前 8 条的 `MetamagicRod` 都是 null。

## 当前规则用到的编号

| 用途 | 32 位编号 | 配置里的键 | 蓝图名 |
|---|---|---|---|
| Deny Death 增益 | `632cad6b7c66b8449a300c6476fd5e1b` | 裸 GUID | DenyDeathBuff |
| Deny Death 法术 | `1098095d7a88c6747aee67f8d449fa06` | `...@L5` | DenyDeath |
| Mirror Image 增益 | `98dc7e7cc6ef59f4abe20c65708ac623` | 裸 GUID | MirrorImageBuff |
| Mirror Image 法术 | `3e4ab69ada402d145a5e0ad3ad4b8564` | `...@L2` | MirrorImage |
| 虫群和普通群攻 | `edf6e91ca5a468849b8326bcc9c569b2` | `...@L7` | FeastOfBlood |
| Absolute Death | `7d721be6d74f07f4d952ee8d6f8f44a0` | `...@L10` | AbsoluteDeath |
| Finger of Death | `6f1dcf6cfa92d1948a740195707c0dbe` | `...@L7` | FingerOfDeath |
| Hungry Flesh，已禁用 | `0d820abda7693a9418546a47eea62ea2` | `...@L8` | DomainOfTheHungryFlesh |

## 当前 8 条，按执行顺序

### 1. fan-negative-heal

FaN Negative Self-Heal。启用。

自己血量百分比小于 25。动作 Heal，Strongest，Negative，HealSources 1。目标自己。

### 2. fan-deny-death

FaN Deny Death。启用。

自己没有增益 `632cad6b7c66b8449a300c6476fd5e1b` 时，施放 `1098095d7a88c6747aee67f8d449fa06@L5`。目标自己。Sources 1。

战斗中被驱散或没按一键 Buff 时用来补。不因为 Buff It 里已有 Deny Death 而删除。

### 3. fan-mirror-image

FaN Mirror Image。启用。

自己没有增益 `98dc7e7cc6ef59f4abe20c65708ac623` 时，施放 `3e4ab69ada402d145a5e0ad3ad4b8564@L2`。目标自己。Sources 1。

### 4. fan-swarm-missile

名字已改为 FaN Swarm Feast。Id 仍是 `fan-swarm-missile`。启用。

敌人生物类型等于 `Swarm`。施放 `edf6e91ca5a468849b8326bcc9c569b2@L7`。没有备用。目标 21。

不再使用 Magic Missile 或 Acid Splash。只有一只虫群时也会放。这和下面至少两名敌人的 Feast 是两条规则，不合并。

### 5. fan-absolute-death

FaN Absolute Death。启用。同一个条件组里两条并且：

- 主体 6，血量百分比大于 40
- 主体 6，SpellDCMinusSave 大于等于 0

施放 `7d721be6d74f07f4d952ee8d6f8f44a0@L10`。没有备用。目标 17。Sources 1。

FaN Finger of Death。启用。条件和上一条形式相同，但 `DC − 豁免` 按 Finger of Death 自己的法术计算。

施放 `6f1dcf6cfa92d1948a740195707c0dbe@L7`。没有备用。目标 17。Sources 1。

### 7. fan-feast-of-blood

FaN Feast of Blood。启用。同一个条件组里两条并且：

- 敌人人数，血量百分比大于 0，人数大于等于 2
- 威胁最高的敌人，血量百分比大于 0

施放 `edf6e91ca5a468849b8326bcc9c569b2@L7`。目标 21。Sources 1。

### 8. fan-hungry-flesh

FaN Hungry Flesh。`Enabled` 为 false。内容保留。

法术仍是 `0d820abda7693a9418546a47eea62ea2@L8`，目标 21。不自动施放。2026-09-27 从本机蓝图和 `Assembly-CSharp.dll` 确认：普通版会打到友军。详见文末当前结论。

## 已查、尚未加入战术的法术

“已准备几发”来自 2026-04-11 手动存档 `Manual_1_Threshold`，不能当成 2026-09-27 的法术书。名称和编号来自本机 `Bundles\cheatdata.json`。Restore Undead 的范围和治疗方式已从 `blueprints.zip` 核实，见文末。

| 法术 | Blueprint Name | 32 位 GUID | 环位 | 法术书 | 保存类型 |
|---|---|---|---|---|---|
| Corrupt Magic | CorruptMagic | `6fd7bdd6dfa9dd943b36d65faf97ac41` | 9 | 有 | 已知，已准备 5 发 |
| Exsanguinate | Exsanguinate | `291524731e8b8f440b44915be833ae07` | 5 | 有 | 已知，这份存档未准备 |
| Siphon Life | SiphonLife | `7bd52a86498c7854ebe99bc3cfb85bfe` | 6 | 有 | 已知，这份存档未准备 |
| Consume Undead | ConsumeUndead | `0e633cc133207a849915e4d15dec8410` | 4 | 有 | 已知，这份存档未准备 |
| Restore Undead | RestoreUndead | `a9dbff7a630003d4eafa6c9dd203cb7e` | 7 | 有 | 已知，这份存档未准备 |
| Negative Eruption | NegativeEruption | `5c377ad96e3fc4f4d9b74eba9d38f4f8` | 9 | 有 | 已知，已准备 1 发 |

若要写入战术，键是 `32位GUID@L环位`。Negative Eruption 不要自动加入，除非本机蓝图能证明它不会治疗敌方不死生物。

## 分析时请遵守

- 法术键必须带 `@L环位`。
- `HasBuff` 用增益编号，不用法术编号。
- 不要把 FaN 的治疗改成正能量。
- 不要因为某次次数是 0 就删规则。
- 不要给 FaN 以外的单位加 `CharacterRules`。
- Hungry Flesh 保持禁用。不要改成 `#256`。不要因为马的一次 0 伤害就启用。
- Corrupt Magic 保持手动。
- 不要改 Buff It。

## 2026-09-27 核对：TabletopTweaks 与 Restore Undead

本机 `Mods` 目录只有 BuffIt2TheLimit、PuzzleSkip、RespecWrath、ToyBox、WrathTactics。没有 TabletopTweaks-Base、TabletopTweaks-Core，也没有其他名称里带 Tweaks 的模组。因此不存在 `SelectiveMetamagicNonInstantaneous` 这项修正。

`fan-hungry-flesh` 保持禁用，AbilityId 仍是普通版 `0d820abda7693a9418546a47eea62ea2@L8`，没有改成 `#256`。区域过滤后来已从蓝图和程序集确认，见文末。

Ally 条件在 1.32.1 的 `EvaluateAllyBucket` 里是同一个队友必须通过该组里全部非人数条件。`GetAllPartyMembers` 使用 `PartyAndPets`，但非人数的 Ally 循环会跳过规则所有者。所以 FaN 自己的血量不会让 `Subject = Ally` 通过。马如果不是不死生物，不能和另一个不死队友的低血量拼成一次通过。

## 2026-09-27 游戏内专长原文

玩家打开的 Selective Spell 说明写明：只有带范围、并且持续时间为 instantaneous 的法术，才能在施放时排除若干目标。没有范围，或者持续时间不是瞬时的法术，不能从这项专长获益。升环是 +1。

Domain of the Hungry Flesh 持续 1 round/level，不是 instantaneous。按这则原文，Selective Hungry Flesh 不能用来保证队友免伤。fan-hungry-flesh 继续保持禁用，也不要把 AbilityId 改成带 #256 的选择性版本。

同一屏的 Persistent Spell 要求法术有豁免检定，升环 +2。Hungry Flesh 没有豁免，Persistent 对它也没有用。

法术书 8 环界面上，Domain of the Hungry Flesh 和 Horrid Wilting 各有一个带数字 8 的条目。7 环已知列表里能看到 Restore Undead。这是法术书已知页，不是记忆栏次数。

## 2026-09-27 15:28 战斗截图

画面战斗记录只有一行：FaN casts Domain of the Hungry Flesh。没有 Selective 字样，也没有马的伤害、绊倒、缠绕或属性伤害。马站在绿色区域里。磁盘上的 combatLog.txt 这次会话仍是 0 字节，引擎日志里也没有这行施法。这一帧不能证明后续回合的持续效果不打队友。

## 2026-09-27 15:37 玩家观察

玩家报告马站在 Domain of the Hungry Flesh 区域内超过 3 个回合，没有出事。画面战斗记录只有 “FaN casts Domain of the Hungry Flesh.”，没有 Selective 字样，也没有马的伤害、绊倒、缠绕或属性伤害行。磁盘 combatLog.txt 仍是 0 字节，GameLog 里没有这句施法。自动规则 fan-hungry-flesh 保持禁用。这次观察没有敌人做阳性对照，不能推翻下面的程序集结论。

## 2026-09-27 16:10 当前结论

游戏配置没有改。本轮只更新了这份说明。

| 文件 | 大小 | SHA256 |
|---|---|---|
| 游戏内 Buff It | 59,648 | `BE754048475AB0F892BF27257CFD4291C5A1ACC486A1FCA0487414F6B2770AA1` |
| 游戏内 Wrath Tactics | 9,420 | `DFFA124A8138169B972538B52D7D45AD1759E19E2EE0458B716B4BA720300EFD` |

压缩包里的两个 JSON 是这两份文件的副本。`GlobalRules` 仍是空数组。8 条 FaN 规则仍在。`fan-hungry-flesh` 的 `Enabled` 仍是 false。没有 Corrupt Magic。Buff It 在 2026-09-27 17:01 重写过，仍是 75 条；Virtue、Aid、Blessing of Unlife、Death Ward 仍只给马，三种注血仍在 Quick。

当天的法术书以后面的 `Quick_1.zks` 为准，不用 2026-04-11 的手动档。

### Hungry Flesh

来源是本机 `blueprints.zip` 里的 `DomainOfTheHungryFlesh.jbp`、`DomainOfTheHungryFleshArea.jbp`，以及 `Assembly-CSharp.dll` 的 `AreaEffectEntityData.IsSuitableTargetType` 和 `CheckSelective`。

区域编号 `6df8ed6ff8ac4974aba16eca1b7b5cbe`。目标类型 `Any`（这套枚举里是 0）。`AffectEnemies` 为 true。半径 20 英尺，持续回合数等于施法者等级。每轮对区域内单位依次做：

- 用施法属性和施法者等级做一次 Trip
- 反射失败则上缠绕，增益 `16ed1bf618c6e364b9c0aca9ce8cb54a`
- `2d6 + 施法者等级` 钝击，无豁免，无法术抗力
- 随机 `1d4` 力量、敏捷或体质属性伤害，无豁免

普通施放会打到施法者、友军、动物伙伴和友方召唤物，也会打到敌人和中立单位。`m_CanAffectAllies` 默认是真。只有本次施放带 Selective（超魔位 256）才会把这个字段改成假。专长说明写 instantaneous，但 `AddMetamagic` 和专长蓝图都没有这条持续时间限制。普通版保持关闭。Selective 的实际排除范围见 16:33 补充。Persistent 不用于 Hungry Flesh。

马超过 3 回合没有掉血，和这份实现不一致。ToyBox 的 `toggleNoFriendlyFireForAOE` 当前是 false。行动自如可以挡缠绕，挡不住钝击。羽步只挡困难地形。防死结界挡的是负能量和能量吸取。虚空祝福的 5 点伤害减免会被钝击穿透。按 20 级施法者，每跳至少约 22 点钝击。0 点生命更像马没有进入真实圆柱，而不是法术只打敌人。

普通版不再做第二次对照测试，也不要自动化。马那次 0 伤害不能当成友军过滤。

### Restore Undead

蓝图 `a9dbff7a630003d4eafa6c9dd203cb7e`，7 环，键 `a9dbff7a630003d4eafa6c9dd203cb7e@L7`。个人范围，标准动作，没有材料成分，也没有额外资源池。施放目标只能是自己，区域中心因此是 FaN。`AbilityTargetsAround` 再取 100 英尺内、有视线、活着的单位。

`Ally` 走 `IsAlly`。FaN 属于玩家阵营时，自己、玩家阵营队友和马都会留在名单里。治疗还要有事实 `NegativeEnergyAffinity`（`d5ee498e19722854198439629c1841a5`）。有这个事实就直接补满当前生命，不包括尸体。

亡灵免疫会授予这个事实，亡灵类型会授予亡灵免疫。巫妖本体特征会给 FaN 加上亡灵类型，所以 FaN 自己会被补满。已经是亡灵类型的队友也会被补满。普通马没有这个事实，治疗动作是空的。马如果挂着虚空祝福，或主人开了亡灵坐骑，马会得到这个事实，那时也会被直接补满。

Wrath Tactics 的 `Target.Type` 用 0（Self）。触发条件用同一个盟友同时满足亡灵类型且生命低于 30%。马单独低血不会触发。一旦施放，100 英尺视线内所有带该事实的友方都会被补满。确认今天已经准备这发之前，不要设 `Enabled` 为 true。规则还没有写进战术文件。

若确认今天已经准备，将来顺序改为 Restore Undead 在负能量自疗前面。原因和缺口见 16:33 补充。规则仍未写入。

### Persistent Finger of Death 与 Corrupt Magic

现有 `fan-finger-of-death` 保持普通键 `6f1dcf6cfa92d1948a740195707c0dbe@L7`，目标 17，条件仍是生命高于 40% 且 `DC − 豁免 >= 0`。磁盘上没有 2026-09-27 的法术书，不能报告 Persistent 版本是否存在、真实键或实际环位。不要凭超魔枚举构造键。Persistent 的安装枚举值是 128，只作对照，不是一条已存在的 AbilityId。

Corrupt Magic（`6fd7bdd6dfa9dd943b36d65faf97ac41`，9 环）继续手动。1.32.1 没有可驱散增益数量、任意增益或首领这类条件。

Horrid Wilting、Embrace of Death、Greater Bestow Curse、Feast of Blood、Absolute Death 的 Persistent 版本先不查。Absolute Death 已是 10 环，Persistent 再加 2 环就放不出来。

## 2026-09-27 16:33 Selective 路径

`m_CanAffectAllies` 只在两处构造函数和 `CheckSelective` 里被写入。运行时构造函数先把它设为真，然后立刻调用 `CheckSelective`。之后唯一的读取点是 `IsSuitableTargetType`。回合处理不会改写它。

`CheckSelective` 取区域上下文的根，转换成 `AbilityExecutionContext`，再查这次施放的 `HasMetamagic(256)`。这是 Selective 这一位，不是整段掩码必须恰好等于 256。根上下文不是法术上下文，或这次施放没有这一位时，字段保持真。

Hungry Flesh 区域的 `Any` 同时允许敌人和友军分支，蓝图里也没有 `ContextConditionIsAlly`。因此带 Selective 位时，字段会被写成假，并留在这块区域对象上。

每轮的绊倒、缠绕、钝击和属性伤害都在同一份 `Round` 动作列表里，没有各自的阵营条件。`OnRound` 只遍历已经在 `InGameUnitsInside` 里的单位。单位要进这个名单，必须通过 `ShouldUnitBeInside`，其中包含 `IsSuitableTargetType`。后来走进区域的单位也走同一次检查。友军分支在字段为假时返回失败，进不去，四项效果都不会执行。

会被排除的是：施法者自己、玩家阵营队友、玩家阵营的马、阵营不是 Neutral 的友方召唤物。

不会被排除的是：敌人，以及单位所属阵营的 `Neutral` 为真的单位。Selective 不保护中立阵营。

`SelectiveSpellFeat` 只有 `AddMetamagicFeat`，超魔是 Selective。`MetamagicBuilder.AddMetamagic` 不检查持续时间是不是 instantaneous。Hungry Flesh 的 `AvailableMetamagic` 包含 Selective。专长说明文字没有变成这条代码路径上的门槛。

读档用的另一个构造函数会把字段设回真，并且不调用 `CheckSelective`。正常战斗中不读档时，字段从生成一直保持到区域结束。

启用前仍要做一次 Selective 实测：敌人在真实区域里连续吃效果，马和不死队友不吃，并且第 2 回合后有一个友军走进已经存在的区域也不吃。通过之前不要写入战术。

2026-09-27 16:44 的手动档是 `Manual_5_AI_CHECK_20260927.zks`。`GameId` 是 `7ea3d466491c4249aec2742271c2e71a`，角色是 FaN，单位 `2c002cb0-2987-4e37-a575-eb5cdd155850`。法术书蓝图 `5a38c9ac8607890409fcb8f6342da6f4`，类型 Mythic。

整份存档里带超魔的法术只有两发：Selective Domain of the Hungry Flesh，和 Selective Horrid Wilting。没有 Persistent。

Selective Hungry Flesh 的已知自定义条目在 8 环，`MetamagicMask` 是 `Selective`。记忆栏有 7 格，`SpellLevel` 都是 8，7 格 `Available` 都是 true。普通版 Hungry Flesh 在已知 8 环里，没有记忆。Wrath Tactics 键按这次存档是 `0d820abda7693a9418546a47eea62ea2@L8#256`。规则仍不要写入，先做 Selective 实测。

Restore Undead 在已知 7 环，来自神话法术表，没有超魔版本，记忆栏是 0 格。今天没有准备。

Finger of Death 在已知 7 环，没有超魔版本，记忆栏是 0 格。Persistent Finger of Death 不存在。

Restore Undead 放在负能量自疗前面是合理的：盟友条件不含 FaN 自己，所以只有别的亡灵低于 30% 才放 Restore，并顺便补满 FaN；没有这样的盟友时才落到自疗。缺口是条件不检查 100 英尺和视线。触发者在范围外时，这发 7 环仍然会放，但补不到那个人。另外自疗线是 25%，FaN 在 25% 到 30% 且没有其他亡灵低于 30% 时，两条都不会放。

## 2026-09-27 16:53 战斗记录

`Quick_2.zks` 是这次战斗后的快速档。`combatLog.txt` 里 Domain of the Hungry Flesh 的反射豁免和 `2d6+32` 钝击只出现在敌人身上：卡拉瓦库斯 8 次，两个魅魔各 2 次。豁免全部成功，所以没有缠绕记录。绊倒只记到两次，都是对卡拉瓦库斯，而且失败。马、FaN 和其他队友没有出现在这些记录里。

FaN 有神话能力 Favorite Metamagic — Selective，蓝图 `3cdc012185334b7da4ed42c6fcc948cf`。它把 Selective 的法术等级附加降低 1，最低到 0。所以 Selective Hungry Flesh 仍占 8 环，不是 9 环。存档里的 `MetamagicMask` 是 `Selective`，战术键仍是 `0d820abda7693a9418546a47eea62ea2@L8#256`。不能用“还在 8 环、格子数量没变”判断这次没放 Selective。规则仍未写入。

## 2026-09-27 17:03 Quicksave1 法术书

文件 `Quick_1.zks`，角色 FaN，GameId `7ea3d466491c4249aec2742271c2e71a`。下面是神话法术书 `5a38c9ac8607890409fcb8f6342da6f4`。整份存档没有任何 Persistent 法术。超魔只有两发：Selective Hungry Flesh，Selective Horrid Wilting。Persistent 没有被设成 Favorite，所以仍是 +2 环。

| 法术 | GUID | 已知环 | 豁免 | 准备 |
|---|---|---|---|---|
| Restore Undead | `a9dbff7a630003d4eafa6c9dd203cb7e` | 7 | 无 | 未准备 |
| Absolute Death | `7d721be6d74f07f4d952ee8d6f8f44a0` | 10 | 意志 | 1 发，已用掉 |
| Corrupt Magic | `6fd7bdd6dfa9dd943b36d65faf97ac41` | 9 | 无 | 5 发可用 |
| Feast of Blood | `edf6e91ca5a468849b8326bcc9c569b2` | 7 | 强韧 | 3 发可用 |
| Finger of Death | `6f1dcf6cfa92d1948a740195707c0dbe` | 7 | 强韧 | 未准备 |
| Negative Eruption | `5c377ad96e3fc4f4d9b74eba9d38f4f8` | 9 | 意志 | 1 发可用 |
| Hungry Flesh Selective | `0d820abda7693a9418546a47eea62ea2` | 8 | 无，区域另有反射 | 7 发可用，键 `@L8#256` |
| Embrace of Death | `41e229444616fc045a9da02f19e47f76` | 8 | 意志 | 1 发可用 |
| Exsanguinate | `291524731e8b8f440b44915be833ae07` | 5 | 强韧 | 未准备 |
| Siphon Life | `7bd52a86498c7854ebe99bc3cfb85bfe` | 6 | 无 | 未准备 |
| Siphon Time | `e346cc550c5bfdf428faa7cdb4849d8e` | 6 | 意志 | 未准备 |
| Bone Shield | `0093fc0098c984c43ac239d1211d1311` | 6 | 无 | 2 发可用 |
| Deny Death | `1098095d7a88c6747aee67f8d449fa06` | 5 | 无 | 6 发可用，另 1 发已用 |
| Mirror Image | `3e4ab69ada402d145a5e0ad3ad4b8564` | 2 | 无 | 8 发可用 |
| Bestow Curse, Greater | `6101d0f0720927e4ca413de7b3c4b7e5` | 8 | 蓝图无豁免字段 | 未准备 |
| Horrid Wilting Selective | `08323922485f7e246acb3d2276515526` | 8 | 强韧 | 1 发可用，键 `@L8#256` |
| Consume Undead | `0e633cc133207a849915e4d15dec8410` | 4 | 无 | 未准备 |
| Power Word Kill | `2f8a67c483dfa0f439b293e094ca9e3c` | 9 | 无 | 未准备 |
| Wail of the Banshee | `b24583190f36a8442b212e45226c54fc` | 9 | 强韧 | 未准备 |
| Weird | `870af83be6572594d84d276d7fc583e0` | 9 | 意志，另有强韧 | 未准备 |
| Hold Monster, Mass | `7f4b66a2b1fdab142904a263c7866d46` | 9 | 意志 | 未准备 |

Feast of Blood 的范围目标是 Enemy，并跳过亡灵和构装体。Siphon Time 有意志豁免，30 英尺，目标类型 Any，蓝图里同时有 Haste 和 Slow。Negative Eruption 30 英尺、目标 Any，按有没有 NegativeEnergyAffinity 分两支。Wail of the Banshee 和 Horrid Wilting 的范围类型也是 Any，会跳过亡灵和构装体，活着的马仍可能被打到。

## 2026-09-27 WithinRange、Embrace、读档

`WithinRange`（属性 18）的 `Value` 不是英尺数字。它用 `Enum.TryParse` 读 `RangeBracket`：`Melee`、`Cone`、`Short`、`Medium`、`Long`、`Far`。`LessOrEqual`（5）表示距离不超过该档上限。`Long` 的上限是 30 米，约 98.4 英尺，比 Restore Undead 的 100 英尺略短。`Far` 是 40 米，会把法术够不到的队友也算进去。没有视线条件。同一个 Ally 条件组会把这三项套在同一个队友上。`Undead` 会先转成小写再比对。

Embrace of Death `41e229444616fc045a9da02f19e47f76` 是 8 环，中距离，只打敌人，无法术抗力，意志豁免。成功没有任何效果。失败施加 `03e56d7d819a3ce40a3b00847ff00ea6`，持续回合数等于施法者等级。该增益给出无法行动和倒地，每轮 1d6 体质吸取，然后再做一次意志豁免。后一次成功则移除自身，并施加 1 回合的 `ac6909637864d194ea197ba4c9823fc9`（EmbraceOfDeathBuffStagger）。`SpellDCMinusSave` 读取的就是这次施法的意志豁免。用 `HasBuff` 加上操作符 3 和这个主增益编号，可以避免重复施放。

`Quick_1.zks` 的区域文件里有一片仍在持续的 Hungry Flesh。父法术是 `0d820abda7693a9418546a47eea62ea2`，`Metamagic` 是 `Selective`，`SpellLevel` 是 8，`m_CanAffectAllies` 存成 false。读档构造函数会先把该字段设为 true，但当前存档格式会把这个字段和持续时间、坐标写在同一条记录里，加载时写回 false。`OnPostLoad` 不会改它，也不会重新调用 `CheckSelective`。

## 2026-09-27 17:36 已写入的 9 条

游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1736`。Wrath Tactics 新校验和是 `7660468B820D24D8FB3E9EEBD98861FEE1C9FD71D9113B1E20EE414D64A2890F`。Buff It 没有改，校验和仍是 `BE754048475AB0F892BF27257CFD4291C5A1ACC486A1FCA0487414F6B2770AA1`。这和更早的 `6A7B0F69...` 不同，因为 Buff It 在 17:01 已经重写过；本轮没有动它。

`Target.Type` 23 是 `GetEnemyMostEnemyNeighbors`。它在可见敌人里用 5 米半径找最密集的那一个敌人，区域落在这个敌人身上，不是两组敌人之间的空地中心。

FaN 顺序：

1. `fan-negative-heal`
2. `fan-deny-death`
3. `fan-mirror-image`
4. `fan-swarm-missile`
5. `fan-absolute-death`，目标仍是 17
6. `fan-embrace-of-death`，新规则，`41e229444616fc045a9da02f19e47f76@L8`，目标 17。最大威胁生命大于 40，`SpellDCMinusSave` 大于等于 0，没有主增益 `03e56d7d819a3ce40a3b00847ff00ea6`，也没有 `ac6909637864d194ea197ba4c9823fc9`
7. `fan-finger-of-death`，目标仍是 17
8. `fan-hungry-flesh`，已启用。键 `0d820abda7693a9418546a47eea62ea2@L8#256`。敌人人数大于等于 3，战斗轮次小于等于 2，最大威胁生命大于 50。目标 23。冷却 3
9. `fan-feast-of-blood`

其余 7 条旧规则的内容没有改。`GlobalRules` 仍为空。没有其他角色的规则。Persistent 没有加入。

## 2026-09-27 17:46 Restore Undead 已插到最前

`Quick_1.zks` 写于 17:43，游戏内日期 18 Arodus，FaN 的神话法术书里 Restore Undead 有 1 发可用。同一本书里 Finger of Death 1 发可用，Feast of Blood 2 发可用。游戏关闭后写入。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1746`。新的 Wrath Tactics 校验和是 `2E4E910E9EBC1AAF46FB59A76BD950E1644ECB39E7E712E9D805838CA380F9C7`。Buff It 没有改。

`fan-restore-undead` 放在第 1 条，启用，冷却 1，目标 0。同一个盟友同时满足：类型 `Undead`，生命低于 30%，距离档 `Long`。法术键 `a9dbff7a630003d4eafa6c9dd203cb7e@L7`。后面 9 条规则的内容没有改，只是整体后移。

## 2026-09-27 18:02 优先级调整

实测 Hungry Flesh 一次都没放。原因是它排在补 buff 和单体攻击后面，标准动作先被占掉，而且条件里还有战斗轮次不超过 2。Corrupt Magic 按最高难度改成最先放。Deny Death 和 Mirror Image 已经在 Buff It 里，从战术规则中删除。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1802`。新校验和是 `17EAF79EED881C2FAF99718725B77F0E072D875306D7A51EA6C3EAC51796C0B1`。Buff It 没有改。

当前顺序：

1. `fan-corrupt-magic`。任意还没有增益 `9f1252226cde84040859bbf1cfbcf0bb` 的敌人，目标 17。冷却 1。多个敌人会逐个放，debuff 消失后再放。键 `6fd7bdd6dfa9dd943b36d65faf97ac41@L9`
2. `fan-restore-undead`
3. `fan-negative-heal`
4. `fan-hungry-flesh`。去掉战斗轮次限制。Selective `@L8#256`、目标 23。冷却 30，避免区域还在时再铺一层。2026-09-27 18:07 又去掉了“敌人至少 3 个”。1 个敌人、最大威胁生命高于 50% 也会放。Feast of Blood 同样去掉了“至少 2 个敌人”，最大威胁还活着就会放。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1807`。这次的校验和是 `4D134E5900B07FF18654F385C9250052F2EE0F89FD60DF2C5E1D6EF547B1C206`
5. `fan-swarm-missile`
6. `fan-absolute-death`
7. `fan-embrace-of-death`
8. `fan-finger-of-death`
9. `fan-feast-of-blood`

## 2026-09-27 18:11 Hungry Flesh 不再看生命

“敌对目标还站在 Selective Hungry Flesh 范围里就不要再放，走出范围再放”做不到。Wrath Tactics 1.32.1 没有“这个单位是否站在某片区域里”的条件，也没有“这片 Hungry Flesh 是否还在”。`HasDescriptorEffect` 只看单位身上已经带有的法术描述符。这片区域不会给站在里面的每个人挂一个增益。缠绕增益 `16ed1bf618c6e364b9c0aca9ce8cb54a` 只在反射豁免失败时出现，离开区域会被拿掉。上一场反射全部成功，人站在区域里也没有这个增益，所以不能用它代替“还在范围里”。

已经拿掉“最大威胁生命高于 50%”。现在只要求正在战斗：主体 5，属性 14（`IsInCombat`），操作符 2，值 `true`。键仍是 `0d820abda7693a9418546a47eea62ea2@L8#256`，目标 23，冷却 30。冷却大约盖住施法者等级那么长的持续时间，所以区域按理还在的时候不会再铺一层。

做不到的部分：敌人提前走出区域时，规则看不到，要等这 30 回合冷却结束才会再放。把冷却改短可以更早补放，但人还站在旧区域里时也会再放一层。

游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1811`。校验和是 `418A4A12142773F69A50324DAF3757BCEA66ABFFE864C040759C117211BEABAF`。另外 8 条没有改。Buff It 没有改。

## 2026-09-27 18:16 Hungry Flesh 排到第二

Corrupt Magic 仍是第 1 条。Hungry Flesh 从第 4 条改到第 2 条。条件、法术键、目标和冷却都没改：正在战斗就放，键 `0d820abda7693a9418546a47eea62ea2@L8#256`，目标 23，冷却 30。

还有敌人没挂上 Corrupt Magic 时，这一回合仍先放它。Hungry Flesh 用下一个空出来的标准动作。它冷却中的回合，后面的治疗和单体法术照常判断。同一回合如果治疗和 Hungry Flesh 都能放，会先放 Hungry Flesh，治疗等下一回合。

当前顺序：

1. `fan-corrupt-magic`
2. `fan-hungry-flesh`
3. `fan-restore-undead`
4. `fan-negative-heal`
5. `fan-swarm-missile`
6. `fan-absolute-death`
7. `fan-embrace-of-death`
8. `fan-finger-of-death`
9. `fan-feast-of-blood`

各条内容没有改，只改了顺序。游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1816`。校验和是 `D25D067627D58B8902606982FFDEF7CBF3CB7769F12DEB463C75571A7CE47B62`。Buff It 没有改。

## 2026-09-27 18:39 Hungry Flesh 连放到没有格子

玩家选择「连放，放光再干别的」。Corrupt Magic 仍是第 1 条。Hungry Flesh 仍是第 2 条，条件仍是正在战斗，键仍是 `0d820abda7693a9418546a47eea62ea2@L8#256`，目标仍是 23。冷却从 30 改为 0。0 乘 6 秒还是 0，所以每个还有标准动作的回合都会再放一片，旧的区域不会被清掉，伤害按片数叠加。

这个法术没有可用次数时，规则执行失败，同一回合继续看后面的规则，不会把回合卡死。Restore Undead、自己的负能量治疗、以及后面的单体都排在 Hungry Flesh 用完之后。

顺序没有改。另外 8 条的内容没有改。游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1840`。校验和是 `FA0B1588A0B13331EAC9FD766266F05400CB3BE4E725E9BEA93C5DDA208F2487`。Buff It 没有改。

## 2026-09-27 19:39 攻击法术改为最近的敌人

实测主角会跑到远处去放。原因是 Corrupt Magic 的目标是第一个还没挂上增益的敌人，Hungry Flesh 的目标是最密集的那一堆，单体法术的条件看的是威胁最高的敌人。这些人都可能站在很远的地方。

攻击法术的目标改成类型 4，也就是可见敌人里离 FaN 最近的那个。Corrupt Magic、Absolute Death、Embrace of Death、Finger of Death、Feast of Blood、虫群那条的条件主体从“任意敌人”或“威胁最高”改成 21（最近的敌人）。最近的人已经挂上 Corrupt Magic，这条就失败，不再追更远的人。最近的人豁免太高，单体法术也不追更远的人。Hungry Flesh 仍是战斗中就放、冷却 0，只是落点改到最近的敌人身上。

Restore Undead 和自己的负能量治疗没改，目标仍是自己。顺序没改。游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-1944`。校验和是 `45DD3388FCA301A9565B20F34E109B15C0B7EEED7F030FC577501BBED31807C2`。Buff It 没有改。

## 2026-09-27 21:40 三个 10 环接在 Hungry Flesh 后面

Hungry Flesh 没有次数之后，先放这三个，再回到原来的治疗和单体。游戏当时没有在运行。

友军伤害只看蓝图的目标类型，不看说明文字。Death's Realm 的 `AbilityTargetsAround` 是 `Enemy`，半径 80 英尺，以施法者为中心。血量伤害在强韧失败时才结算，而且跳过亡灵和构装体；`1d4` 永久负向等级在豁免外面，敌人豁免成功也会吃到。法术抗力可以整段挡掉。队友和马不在目标里。

Doom to Servitude 只能点一个非亡灵、非构装的敌人，`CanTargetFriends` 是假。诅咒增益 `b7043130aeffe094285c8c74cd0ff576` 先挂上，强韧失败才吃开场的不洁伤害。增益每回合再造成一次不洁伤害，死时另挂两个增益。没有法术抗力。

Pit of Despair 的区域类型是 `Any`，半径 20 英尺。站在里面的人都会掉进坑，坠落伤害不看阵营，攀爬 DC 25。每回合的负能量伤害只打没有 NegativeEnergyAffinity 的生物，马会吃到，亡灵队友不吃这段负能量，但一样会掉下去。夜影是施法者的召唤。所以三个里面只有这一条会打到自己人。

顺序：

3. `fan-deaths-realm`。冷却 0，目标自己。正在战斗，且最近的敌人在 `Long` 以内。键 `16c3fe873538010459a8a3fd61304825@L10`
4. `fan-doom-to-servitude`。冷却 0，目标最近的敌人。最近的人不是亡灵、不是构装、还没有那条诅咒，并且在 `Medium` 以内。键 `24067ba8e0e69a14e83ff397826f6c6d@L10`
5. `fan-pit-of-despair`。冷却 30，目标最近的敌人，最近的人在 `Medium` 以内。只放一次，避免坑还在时再放。键 `cc74245ba989480488925214dd925100@L10`

Corrupt Magic 和 Hungry Flesh 仍是前两条，内容没改。治疗和后面的单体整体后移，内容没改。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-2145`。校验和是 `813E985A12A29ED253D1B389F96062026951BDB28B39C36C49CC3A0890616A44`。Buff It 没有改。

Buff It 这份副本换成了游戏目录里的现文件。校验和是 `96C1EF3F4E76817E94DDA2EA1795B2D447D7A31A40B3BE6D4AEA405A9FD17088`。法师护甲多了马 `55FD` 这个来源，其余 75 条还在。本轮没有改 Buff It 的内容。

## 2026-09-27 22:02 去掉死亡领域和奴役厄运

`fan-deaths-realm` 和 `fan-doom-to-servitude` 已从战术里删除。`fan-pit-of-despair` 留下，仍在 Hungry Flesh 后面，冷却 30，目标最近的敌人，键 `cc74245ba989480488925214dd925100@L10`。

Hungry Flesh 没有次数之后，下一个攻击法术是绝望深坑。它冷却的时候才轮到 Restore Undead、自己的负能量治疗和后面的单体。其余规则内容没改。游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-2202`。校验和是 `F2E8B0813A391A887D4E21A7B2CFFBBF2179B847FFB0FED8709C3B7811BB1980`。Buff It 没有改。

## 2026-09-27 22:08 绝望深坑改为一直放

`fan-pit-of-despair` 冷却从 30 改为 0。条件改成只看是否正在战斗，和 Hungry Flesh 一样。目标仍是类型 4，最近的敌人。键仍是 `cc74245ba989480488925214dd925100@L10`。

Hungry Flesh 没有次数之后，每个还有标准动作的回合都放绝望深坑，直到这个法术也没有次数。没有次数时同一回合才轮到治疗和后面的单体。其他规则没改。游戏当时没有在运行。备份是 `tactics-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-2209`。校验和是 `4798A6329118471278DEA467218873AD70C03B6A621CAADC3B98BF6D413CC0C0`。Buff It 没有改。
