# 一键 Buff（Buff It 2 The Limit）当前配置说明

这份说明只覆盖一键 Buff。Wrath Tactics 不在这里。

给 ChatGPT 的任务：根据下面的文件结构和当前配置，提出要改的目标名单和分组。不要因为界面显示 0 发就建议删除条目。0 发只表示当时没休息，或者这个法术还没放进法术书。请用本文里的单位编号和带连字符的法术编号写出具体改法。

快照时间：2026-09-27。游戏当时已关闭。同目录的 `buffit-current-config.json` 是当时的完整配置副本。游戏真正读取的文件不在这个压缩包里。

## 游戏真正读取的文件

```
D:\SteamLibrary\steamapps\common\Pathfinder Second Adventure\Mods\BuffIt2TheLimit\UserSettings\bi2tl-7ea3d466491c4249aec2742271c2e71a.json
```

- 模组：Buff It 2 The Limit 1.21.1
- 文件名里的 `7ea3d466491c4249aec2742271c2e71a` 是这份存档的 GameId
- 存档角色：FaN
- 存档地点：Threshold，游戏内日期 17 Arodus 4715
- 存档文件：`Manual_1_Threshold__17_Arodus__VIII__4715__21_23_05.zks`
- 这个 JSON 是一整行，没有换行

同目录还有另外两个存档的配置，不要改它们：

- `bi2tl-fea04e92a6f54507a84b86b8444eec8f.json`：角色 Hansen
- `bi2tl-a7c04407c8e142ffa2629983a3c6702d.json`：另一份存档

## 界面上的三个按钮

| 游戏按钮 | JSON 里的分组名 | 当前条目 |
|---|---|---|
| Normal Buffs | `Long` | 除下面 3 条以外的全部 |
| Quick Buffs | `Quick` | Sickening Infusion、Focused Infusion、Commanding Infusion |
| Important Buffs | `Important` | 没有条目 |

按 Normal 会尝试施放所有 `InGroups` 含 `Long` 的条目。按 Quick 只尝试 `Quick`。噬血法师的三种注血会扣 FaN 自己的血，所以放在 Quick，不放在 Normal。

## 编号格式

Buff It 里的法术编号和法术书编号都是带连字符的 GUID，分成 8-4-4-4-12。

游戏蓝图和 Wrath Tactics 用的是去掉连字符的 32 位小写十六进制。两边是同一个编号。

例子：

- Buff It：`9e1ad5d6-f87d-19e4-d888-3d63a6e35568`
- 无连字符：`9e1ad5d6f87d19e4d8883d63a6e35568`
- 这个编号的蓝图名是 `MageArmor`

名字来自游戏安装目录里的 `Bundles\cheatdata.json`。那份表的字段是 `Name`、`Guid`、`TypeFullName`。`Guid` 不带连字符。

## 顶层字段

当前值：

| 字段 | 当前值 | 含义 |
|---|---|---|
| `Version` | 1 | 配置版本 |
| `VerboseCasting` | false | 不写详细施法日志 |
| `SkipAnimationsOnCombatStart` | false | 战斗开始时不跳过动画 |
| `CastAllOnCombatStart` | false | 不在战斗开始时自动施放全部增益 |
| `AllowInCombat` | false | 战斗中不使用这一键 |
| `BypassArcaneSpellFailure` | false | 不忽略奥术失败 |
| `OverwriteBuff` | false | 不覆盖已经存在的同类增益 |
| `GlobalSourcePriority` | 0 | 施法来源的全局优先级，0 是默认 |
| `CasterRanks` | {} | 空 |
| `MountPreference` | 空 | 未设置坐骑偏好 |
| `FuryWeaponPreference` | 空 | 未设置 |
| `UmdRetries` | 3 | 使用魔法装置失败后的重试次数 |
| `UmdMode` | 1 | 使用魔法装置的模式，数值原样保留 |
| `ScrollsEnabled` | true | 允许用卷轴 |
| `PotionsEnabled` | true | 允许用药水 |
| `EquipmentEnabled` | true | 允许用装备上的能力 |
| `SongsEnabled` | true | 允许用歌唱 |
| `ActivatablesEnabled` | true | 允许开关型能力 |
| `SortByName` | false | 界面不按名字排序 |
| `ShortcutKeys` | {} | 没有快捷键 |
| `OpenBuffMenuKey` | Key=None，Ctrl/Shift/Alt 都是 false | 没有打开菜单的快捷键 |

## 一条增益的结构

`Buffs` 是数组。每一项是 `Key` 加 `Value`。

```json
{
  "Key": {
    "Guid": "法术或能力的蓝图编号，带连字符",
    "MetamagicMask": 0,
    "Archmage": false
  },
  "Value": {
    "InGroup": 0,
    "InGroups": ["Long"],
    "Blacklisted": false,
    "IgnoreForOverwriteCheck": null,
    "Wanted": ["要接受这个增益的单位编号"],
    "Casters": [
      {
        "Key": {
          "Name": "施法者单位编号",
          "Spellbook": "法术书蓝图编号，带连字符；没有则为全 0",
          "SourceType": 0
        },
        "Value": {
          "Banned": false,
          "Cap": -1,
          "PriorityOverride": null,
          "ShareTransmutation": false,
          "PowerfulChange": false,
          "ReservoirCLBuff": false,
          "UseAzataZippyMagic": false
        }
      }
    ],
    "BaseSpell": "00000000-0000-0000-0000-000000000000",
    "SourcePriorityOverride": -1,
    "UseSpells": true,
    "UseScrolls": true,
    "UsePotions": true,
    "UseEquipment": true,
    "UseExtendRod": false,
    "CastOnCombatStart": false,
    "DeactivateAfterRounds": 0
  }
}
```

字段含义：

- `Key.Guid`：要施放的法术或能力。
- `Key.MetamagicMask`：0 表示没有超魔。当前 75 条都是 0。
- `Key.Archmage`：当前都是 false。
- `InGroups`：这一条属于哪个按钮。当前只用了 `Long` 和 `Quick`。
- `InGroup`：旧的数字字段，当前都是 0。以 `InGroups` 为准。
- `Blacklisted`：true 时不施放。当前都是 false。
- `Wanted`：接受增益的单位。一键 Buff 只会给这个名单里的人加。
- `Casters`：允许施放这一条的人。
- `Casters.Key.Name`：施法者单位编号。
- `Casters.Key.Spellbook`：使用哪本法术书。全 0 表示这条施法者记录没有绑定法术书。
- `Casters.Key.SourceType`：0 是法术书施法。1 和全 0 法术书一起出现，表示卷轴或其他非法术书来源。4 出现在开关型能力上，例如吟游诗人的歌唱开关。
- `Cap`：-1 表示不限制施放次数。
- `Banned`：true 时这个施法者被禁止施放这一条。
- `SourcePriorityOverride`：-1 表示沿用全局来源优先级。
- `UseSpells` / `UseScrolls` / `UsePotions` / `UseEquipment`：这一条允许从哪些来源施放。
- `UseExtendRod`：是否使用延时超魔杖。当前都是 false。
- `CastOnCombatStart`：是否在战斗开始时单独施放。当前都是 false。
- `DeactivateAfterRounds`：0 表示不按回合关闭。

## 单位编号

这些编号来自 Buff It 的 `Wanted` 和 `Casters`，并与存档 `party.json` 里的 `m_OwnerRef` 对应。

| 单位编号 | 存档里能确定的事实 | 法术书编号 |
|---|---|---|
| `2c002cb0-2987-4e37-a575-eb5cdd155850` | FaN。半血裔、法师 20、噬血法师变体、巫妖神话职业 8 级、神话起始职业 2 级，合计神话 10 阶。有不死生物类型。 | `5a38c9ac-8607-8904-09fc-b8f6342da6f4` |
| `56A0` | 吟游诗人，带神话同伴等级。有不死生物类型。 | `bc04fc15-7a88-01d4-1b87-7ad0d9af03dd` |
| `57A6` | 战斗祭司，带神话同伴等级。有不死生物类型。 | `7d7d51be-2948-d254-4b3c-2e1596fd7603` |
| `2805` | 有法术书。有不死生物类型。职业名没有从存档文本里直接读出。 | `d731dfb3-9ea2-6754-c89b-58d0969ea9e0` |
| `5568` | 有不死生物类型。 | 无绑定法术书 |
| `5611` | 有不死生物类型。 | 无绑定法术书 |
| `5728` | 有不死生物类型。 | 无绑定法术书 |
| `55FD` | 这 8 个编号里唯一没有不死生物类型的单位。战术界面里有一个 Horse 位，这个编号按那匹马来用。 | 无绑定法术书 |

不死生物类型的蓝图编号是 `734a29b693e9ec346ba2951b27987e33`，名字是 `UndeadType`。存档里上述 7 个单位各有一条，`55FD` 没有。

界面上的队友页还有 Ciar、Queen Galfrey、Delamere、Staunton Vhane、Kestoglyr、Skeletal Marksman。存档 JSON 不把这些显示名写在单位编号旁边，所以这张表不把短编号猜成某一个名字。

## 已经按巫妖队改过的目标

条目都还在。改的是 `Wanted` 和分组。

| 蓝图名 | 编号 | 分组 | 现在打给谁 | 原因 |
|---|---|---|---|---|
| Virtue | `d3a85238-5ba4-cd74-0992-d1970170301a` | Long | 只有 `55FD` | 正能量戏法，会伤到负能量亲和 |
| DeathWardCast | `e9cc9378-fd68-41f4-8ad5-9384e79e9953` | Long | 只有 `55FD` | 免疫负能量，会挡住巫妖和不死队友接受负能量治疗 |
| BlessingOfUnlife | `2abf1b69-cec7-60d4-ebc7-3d5ce8d79f0a` | Long | 只有 `55FD` | 用来让活人暂时按不死生物处理。已经是不死生物的单位不需要 |
| SickeningInfusionAbility | `18929b7e-343c-49ef-aafa-88f798c11be8` | Quick | 只有 FaN | 噬血法师注血，施放时扣自己的血 |
| FocusedInfusionAbility | `5a5d3a4b-cbc5-4ea1-b858-1923373fd992` | Quick | 只有 FaN | 同上 |
| CommandingInfusionAbility | `6489492a-3499-4d00-926e-8802c3f2b4cf` | Quick | 只有 FaN | 同上 |

Haste、Heroism、Deny Death、Mage Armor 这类仍然打给名单里的整队，包括 FaN。

## 原来的 75 条

列说明：

- 分组：`Long` 是 Normal 按钮，`Quick` 是 Quick 按钮
- 超魔：`MetamagicMask`
- 目标：`Wanted`
- 施法者：`单位/book=法术书/src=来源类型`
- 来源开关：这一条是否允许法术、卷轴、药水、装备、延时杖

| # | 蓝图名 | Buff It 编号 | 无连字符编号 | 分组 | 超魔 | 目标 | 施法者 | 来源开关 |
|---|---|---|---|---|---|---|---|---|

| 1 | Resistance | 7bc8e27c-ba24-f0e4-3ae6-4ed201ad5785 | 7bc8e27cba24f0e43ae64ed201ad5785 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0; 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0; 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 2 | MageArmor | 9e1ad5d6-f87d-19e4-d888-3d63a6e35568 | 9e1ad5d6f87d19e4d8883d63a6e35568 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 57A6, 5568, 56A0, 5611, 5728, 2805, 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0; 2c002cb0-2987-4e37-a575-eb5cdd155850/book=00000000-0000-0000-0000-000000000000/src=1; 5568/book=00000000-0000-0000-0000-000000000000/src=1; 56A0/book=00000000-0000-0000-0000-000000000000/src=1; 5611/book=00000000-0000-0000-0000-000000000000/src=1; 57A6/book=00000000-0000-0000-0000-000000000000/src=1; 5728/book=00000000-0000-0000-0000-000000000000/src=1; 2805/book=00000000-0000-0000-0000-000000000000/src=1 | spells=True scrolls=True potions=True gear=True rod=False |
| 3 | MageShield | ef768022-b078-5eb4-3a18-969903c537c4 | ef768022b0785eb43a18969903c537c4 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 4 | MirrorImage | 3e4ab69a-da40-2d14-5a5e-0ad3ad4b8564 | 3e4ab69ada402d145a5e0ad3ad4b8564 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 56A0, 2805 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0; 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 5 | ProtectionFromEvilCommunal | 93f391b0-c5a9-9e04-e83b-bfbe3bb6db64 | 93f391b0c5a99e04e83bbfbe3bb6db64 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0; 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 6 | ProtectionFromArrowsCommunal | 96c9d98b-6a9a-7c24-9b6c-4572e4977157 | 96c9d98b6a9a7c249b6c4572e4977157 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 7 | EyesOfTheBodak | e9c9a61b-81a2-9794-2a32-6c91da2af8ca | e9c9a61b81a297942a326c91da2af8ca | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 8 | VampiricBlade | 81ac91fe-9224-0a84-78b5-d2512c9fbec2 | 81ac91fe92240a8478b5d2512c9fbec2 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 9 | FalseLifeGreater | dc6af3b4-fd14-9f84-1912-d8a3ce0983de | dc6af3b4fd149f841912d8a3ce0983de | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 10 | VampiricShadowShield | a3492103-5f2a-6714-e9be-5ca76c5e34b5 | a34921035f2a6714e9be5ca76c5e34b5 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 11 | MindBlankCommunal | 87a29feb-d010-9934-19f2-a4a9bee11cfc | 87a29febd010993419f2a4a9bee11cfc | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 12 | UnbreakableHeart | dd38f33c-56ad-00a4-da38-6c1afaa49967 | dd38f33c56ad00a4da386c1afaa49967 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 13 | Haste | 486eaff5-8293-f644-1a5c-2759c4872f98 | 486eaff58293f6441a5c2759c4872f98 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 14 | Heroism | 5ab0d42f-b68c-9e34-abae-4921822b9d63 | 5ab0d42fb68c9e34abae4921822b9d63 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 15 | FreedomOfMovementCast | 0087fc2d-64b6-0954-78bc-7b8d7d512caf | 0087fc2d64b6095478bc7b8d7d512caf | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0; 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 16 | CloakofDreams | 7f71a70d-822a-f944-58dc-1a235507e972 | 7f71a70d822af94458dc1a235507e972 | Long | 0 | 56A0 | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 17 | Virtue | d3a85238-5ba4-cd74-0992-d1970170301a | d3a852385ba4cd740992d1970170301a | Long | 0 | 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 18 | Guidance | c3a8f317-78c3-9804-98d8-f00c980be5f5 | c3a8f31778c3980498d8f00c980be5f5 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 19 | Prayer | faabd2cc-67ef-a464-6ac5-8c7bb3e40fcc | faabd2cc67efa4646ac58c7bb3e40fcc | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 20 | DivinePower | ef16771c-b05d-1344-9895-19e87f25b3c5 | ef16771cb05d1344989519e87f25b3c5 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 21 | Eaglesoul | 332ad682-73db-9704-ab0e-92518f2efd1c | 332ad68273db9704ab0e92518f2efd1c | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 22 | SlayersAdvanceAbility | 7c7bc929-9a32-08b4-eb89-b3e235af3f36 | 7c7bc9299a3208b4eb89b3e235af3f36 | Long | 0 | 5611 | 5611/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 23 | SickeningInfusionAbility | 18929b7e-343c-49ef-aafa-88f798c11be8 | 18929b7e343c49efaafa88f798c11be8 | Quick | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 24 | DeadlyPerformanceAbility | c182f145-0932-c634-e954-148a9b16618d | c182f1450932c634e954148a9b16618d | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 25 | CavalierLionsCallAbility | 54d608d1-85f0-b9f4-5a56-da7dbd59eb90 | 54d608d185f0b9f45a56da7dbd59eb90 | Long | 0 | 5568 | 5568/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 26 | FocusedInfusionAbility | 5a5d3a4b-cbc5-4ea1-b858-1923373fd992 | 5a5d3a4bcbc54ea1b8581923373fd992 | Quick | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 27 | CommandingInfusionAbility | 6489492a-3499-4d00-926e-8802c3f2b4cf | 6489492a34994d00926e8802c3f2b4cf | Quick | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 28 | CavalierForTheKingAbility | e35e2ea6-a3b6-3894-9baf-78959ef5c5fd | e35e2ea6a3b638949baf78959ef5c5fd | Long | 0 | 5568 | 5568/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 29 | StrengthBlessingMinorAbility | 5bf81563-58e4-48a4-c8b9-ebc347471228 | 5bf8156358e448a4c8b9ebc347471228 | Long | 0 | 57A6 | 57A6/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 30 | SacredWeaponEnchantSwitchAbility | cca63747-a12b-55f4-4ad5-6ef2d840d7f4 | cca63747a12b55f44ad56ef2d840d7f4 | Long | 0 | 57A6 | 57A6/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 31 | EvilBlessingMinorAbility | f5039f03-c9a4-9aa4-0982-48222d3ce451 | f5039f03c9a49aa4098248222d3ce451 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 32 | StrengthBlessingMajorAbility | 0d46406c-fc71-9794-4bd7-5ab76d6abc04 | 0d46406cfc7197944bd75ab76d6abc04 | Long | 0 | 57A6 | 57A6/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 33 | ArcaneWeaponSwitchAbility | 3c89dfc8-2c2a-3f64-6808-ea250eb91b91 | 3c89dfc82c2a3f646808ea250eb91b91 | Long | 0 | 2805 | 2805/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 34 | WarpriestAspectOfWarAbility | 800a5fa9-0c01-b054-0b9a-b9553f744e6e | 800a5fa90c01b0540b9ab9553f744e6e | Long | 0 | 57A6 | 57A6/book=00000000-0000-0000-0000-000000000000/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 35 | InspireCourageToggleAbility | 5250fe10-c377-fdb4-9be4-49dfe050ba70 | 5250fe10c377fdb49be449dfe050ba70 | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 36 | FascinateToggleAbility | 993908ad-3fb8-1f34-ba0e-d168b7c61f58 | 993908ad3fb81f34ba0ed168b7c61f58 | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 37 | InciteRageEnemiesToggleAbility | dbd7c54b-a43e-1d54-592e-037d63117f7b | dbd7c54ba43e1d54592e037d63117f7b | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 38 | InciteRageAlliesToggleAbility | b1d8fdff-d132-bfd4-28a8-045b7b8b363c | b1d8fdffd132bfd428a8045b7b8b363c | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 39 | InciteRageAllToggleAbility | 32d247b6-e6b6-5794-ab47-fc372c444a96 | 32d247b6e6b65794ab47fc372c444a96 | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 40 | StormCallToggleAbility | d5ee8a2e-5bf4-6c54-9988-e9b09a59acd4 | d5ee8a2e5bf46c549988e9b09a59acd4 | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 41 | InspireGreatnessToggleAbility | be36959e-44ac-3364-1ba9-e0204f3d227b | be36959e44ac33641ba9e0204f3d227b | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 42 | InspireHeroicsToggleAbility | a4ce0637-1f09-f504-fa86-fcf6d0e021e4 | a4ce06371f09f504fa86fcf6d0e021e4 | Long | 0 | 56A0 | 56A0/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 43 | DirgeOfDoomToggleAbility | d99d63f8-4e18-0d44-e8f9-2b9a832c609d | d99d63f84e180d44e8f92b9a832c609d | Long | 0 | 2805 | 2805/book=00000000-0000-0000-0000-000000000000/src=4 | spells=True scrolls=True potions=True gear=True rod=False |
| 44 | BoneShield | 0093fc00-98c9-84c4-3ac2-39d1211d1311 | 0093fc0098c984c43ac239d1211d1311 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 45 | FalseGrace | d6b8099f-8c7b-e8f4-492b-14da84dc06d4 | d6b8099f8c7be8f4492b14da84dc06d4 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850 | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 46 | Bless | 90e59f4a-4ada-8724-3b7b-3535a06d0638 | 90e59f4a4ada87243b7b3535a06d0638 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 47 | Aid | 03a96303-94d1-0164-a941-0882d31572f0 | 03a9630394d10164a9410882d31572f0 | Long | 0 | 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 48 | BlessingOfLuckAndResolveCast | 9a7e3cd1-323d-fe34-7a6d-cce357844769 | 9a7e3cd1323dfe347a6dcce357844769 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 49 | DelayPoisonCommunal | 04e820e1-ce3a-66f4-7a50-ad5074d3ae40 | 04e820e1ce3a66f47a50ad5074d3ae40 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 50 | ResistFireCommunal | 832bf989-66e7-2cd4-78ee-cc9f8ba829f5 | 832bf98966e72cd478eecc9f8ba829f5 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 51 | ProtectionFromFireCommunal | 2903d31d-6c83-5654-7aa4-aae5a3e7a655 | 2903d31d6c8356547aa4aae5a3e7a655 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 52 | AngelicAspect | 75a10d5a-6359-8664-1bfb-cceceec87217 | 75a10d5a635986641bfbcceceec87217 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 53 | BurstOfGlory | 1bc83efe-c9f8-c4b4-2a46-162d72cbf494 | 1bc83efec9f8c4b42a46162d72cbf494 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 54 | GeniekindEfreeti | a4864f72-3e17-00d4-785a-c5ad9aefc5f2 | a4864f723e1700d4785ac5ad9aefc5f2 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 55 | RighteousMight | 90810e5c-f53b-f854-293c-bd5ea1066252 | 90810e5cf53bf854293cbd5ea1066252 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 56 | ProfaneNimbus | b56521d5-8f99-6cd4-299d-ab3f38d5fe31 | b56521d58f996cd4299dab3f38d5fe31 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 57 | TrueSeeingCommunal | fa08cb49-ade3-eee4-2b5f-d42bd33cb407 | fa08cb49ade3eee42b5fd42bd33cb407 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 58 | BearsEnduranceMass | f6bcea6d-b14f-0814-d99b-54856e918b92 | f6bcea6db14f0814d99b54856e918b92 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 59 | EaglesSplendorMass | 2caa607e-adda-4ab4-4934-c5c9875e01bc | 2caa607eadda4ab44934c5c9875e01bc | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 60 | BullsStrengthMass | 6a234c6d-cde7-ae94-e94e-9c36fd1163a7 | 6a234c6dcde7ae94e94e9c36fd1163a7 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 61 | BlessingOfLuckAndResolveMass | 462c21ce-bf78-20c4-0a87-f5e4d03e17cf | 462c21cebf7820c40a87f5e4d03e17cf | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 62 | DenyDeath | 1098095d-7a88-c674-7aee-67f8d449fa06 | 1098095d7a88c6747aee67f8d449fa06 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 63 | BlessingOfUnlife | 2abf1b69-cec7-60d4-ebc7-3d5ce8d79f0a | 2abf1b69cec760d4ebc73d5ce8d79f0a | Long | 0 | 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 64 | HeroicInvocation | 43740dab-0728-6fe4-aa00-a6ee104ce7c1 | 43740dab07286fe4aa00a6ee104ce7c1 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 2c002cb0-2987-4e37-a575-eb5cdd155850/book=5a38c9ac-8607-8904-09fc-b8f6342da6f4/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 65 | ShieldOfDawn | 62888999-1719-21e4-dafb-46de83f4d67d | 62888999171921e4dafb46de83f4d67d | Long | 0 | 56A0 | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0; 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 66 | HeroismGreater | e15e5e70-45fd-a224-4b98-c8f010adfe31 | e15e5e7045fda2244b98c8f010adfe31 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 67 | BrilliantInspiration | a5c56f0f-699d-aec4-4b7a-edd8b273b08a | a5c56f0f699daec44b7aedd8b273b08a | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 56A0/book=bc04fc15-7a88-01d4-1b87-7ad0d9af03dd/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 68 | DivineFavor | 9d5d2d3f-fdd7-3c64-8af3-eb3e585b1113 | 9d5d2d3ffdd73c648af3eb3e585b1113 | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 69 | ShieldOfFaith | 183d5bb9-1dea-3a14-89a6-db6c9cb64445 | 183d5bb91dea3a1489a6db6c9cb64445 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 70 | EffortlessArmor | e1291272-c8f4-8c14-ab21-2a599ad17aac | e1291272c8f48c14ab212a599ad17aac | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 71 | ArchonsAura | e67efd8c-84f6-9d24-ab47-2c9f546fff7e | e67efd8c84f69d24ab472c9f546fff7e | Long | 0 | 57A6 | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 72 | CrusadersEdgeCast | be5452c4-22a6-ea74-4bf1-037b0a443bb1 | be5452c422a6ea744bf1037b0a443bb1 | Long | 0 | 5568, 57A6, 5728, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 73 | DeathWardCast | e9cc9378-fd68-41f4-8ad5-9384e79e9953 | e9cc9378fd6841f48ad59384e79e9953 | Long | 0 | 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 74 | DisruptingWeaponCast | 46c96cc3-a3ef-3524-3915-ff3452dfacf5 | 46c96cc3a3ef35243915ff3452dfacf5 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 57A6/book=7d7d51be-2948-d254-4b3c-2e1596fd7603/src=0 | spells=True scrolls=True potions=True gear=True rod=False |
| 75 | FeatherStep | f3c0b267-dd17-a2a4-5a40-805e31fe3cd1 | f3c0b267dd17a2a45a40805e31fe3cd1 | Long | 0 | 2c002cb0-2987-4e37-a575-eb5cdd155850, 5568, 56A0, 5611, 57A6, 5728, 2805, 55FD | 2805/book=d731dfb3-9ea2-6754-c89b-58d0969ea9e0/src=0 | spells=True scrolls=True potions=True gear=True rod=False |

## 分析时请遵守

- 不要建议删除显示 0 发的条目。0 发表示当时没有可用次数，或者法术还没加入法术书。
- 改目标时使用上表的单位编号。不要把短编号猜成某个队友的显示名。
- 改法术时同时给出带连字符的编号和无连字符编号。
- 正能量治疗、Virtue、Death Ward 不要打到有不死生物类型的 7 个单位上。
- 三种注血留在 Quick。不要放回 Long。
- 马 `55FD` 上的 Freedom of Movement、Death Ward、Blessing of Unlife 都挡不住 Hungry Flesh 的钝击伤害。Blessing of Unlife 会给马加上 `NegativeEnergyAffinity`。这个增益在的时候，Restore Undead 会把马的生命直接补满。Feather Step 已从一键列表拿掉，行动自如已经盖住它。
- 建议写成可以直接改 JSON 的清单：条目编号、新的 `Wanted`、新的 `InGroups`。

## 2026-09-27 21:51 补上的增益

对照 Quick_2 存档里 FaN、56A0、57A6、2805 的已知法术。攻击、召唤、正能量治疗、需要现场选择能量或阵营的母法术、变身，没有加。False Life 没加，因为高等虚假生命已经在。Resist Energy Communal 和 Protection from Energy Communal 是母法术，火焰版本已经在。

新增 20 条，都在 Long。现在一共 95 条。

| 蓝图名 | 编号 | 目标 | 施法者 |
|---|---|---|---|
| WindsOfVengeance | `5d8f1da2-fdc0-b924-2af9-f326f9e507be` | FaN | FaN |
| PowerFromDeath | `9c2c85a3-782a-f804-880c-81c1712e3a7b` | FaN | FaN |
| StunningBarrier | `a5ec7892-fb1c-2f74-598b-3a82f3fd679f` | FaN、57A6 | FaN、57A6 |
| ExpeditiousRetreat | `4f8181e7-a7f1-d904-fbae-a64220e83379` | FaN、2805 | FaN、2805 的法师书 |
| Blur | `14ec7a4e-52e9-0fa4-7a4c-8d63c69fd5c1` | 2805 | 2805 法师书 `c9ff1f4b-3b26-dcb4-7ba7-5b218ccadd23` |
| Displacement | `903092f6-488f-9ce4-5a80-943923576ab3` | 2805 | 同上 |
| Blink | `045351f1-421e-e3f4-49a9-143db701d192` | 2805 | 同上 |
| InvisibilityGreater | `ecaa0def-35b3-8f94-9bd1-976a6c9539e0` | 2805 | 同上 |
| Stoneskin | `c66e8690-5f76-06c4-eaa5-c774f0357b2b` | 2805 | 同上 |
| EnlargePerson | `c60969e7-f264-e6d4-b84a-1499fdcf9039` | 2805 | 同上 |
| MagicWeaponGreater | `0f92caa3-5619-f234-298d-95a4b6dda90d` | 5568、5611、57A6、5728、2805、55FD | 57A6，不够时 2805 |
| MagicalVestment | `2d4263d8-0f51-36b4-296d-6eb43a221d7d` | 除 FaN 外的 7 个 | 57A6 |
| OwlsWisdomMass | `9f5ada58-1af3-db44-19b5-4db77f44e430` | 全队 8 个 | 57A6 |
| LifeBubble | `265582bc-494c-4b12-b586-0b508a2f89a2` | 全队 | 57A6 |
| SpellResistance | `0a5ddfbc-fb39-8954-3ac7-c936fc256889` | 全队 | 57A6 |
| RemoveFear | `55a037e5-14c0-ee14-a8e3-ed14b47061de` | 全队 | 57A6 |
| JoyfulRapture | `15a04c40-f845-4594-9abe-edef7279751a` | 全队 | 57A6 |
| Grace | `464a7193-5194-29f4-8b4d-190acb753cf0` | 57A6 | 57A6 |
| Firebelly | `b0652310-94a2-1d14-dbf1-c3832f776871` | 57A6 | 57A6 |
| BlessingOfCourageAndLife | `c36c1d11-771b-0584-f8e1-00b92ee5475b` | 全队 | 57A6 |

游戏当时没有在运行。备份是 `bi2tl-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-2158`。校验和是 `5150221B2200763EAA8EA42E1966B147EACA418C8F02CA0ED933F6CDE82D9CB4`。三种注血仍在 Quick。正能量治疗没有加进来。

## 2026-09-27 22:03 按法术位和覆盖关系删掉不该自动放的

上次加的 20 条没有算法术位、同环竞争、目标人数，也没有算高环盖低环。Quick_2 里战斗祭司 1 到 4 环的格子已经排满原来的增益。2805 的法师书 4 环只有 1 格。FaN 的 9 环 9 格里是 5 发 Corrupt Magic、心灵空白、英雄祈唤、负能量爆发、女妖哀嚎，没有复仇之风。

删掉 18 条：

- 复仇之风：9 环，和英雄祈唤抢格子
- 死亡之力：要身边有尸体才有用，一键预放会空掉
- 震慑屏障：护盾加值，盖不过法师护盾
- 脚底加速：速度加值和加速术相同，加速术已经在
- 模糊术、移位术、闪现术：隐蔽或失手几率不如高等隐形
- 石肤术：和高等隐形抢 2805 仅有的 1 个 4 环
- 高等魔法武器、魔法背心：每人单独一发，近战和穿甲的人太多，4 环和 3 环已经被占满，身上的魔法武器和护甲通常已经有增强加值
- 生命气泡、法术抗力：触碰，每人一发，5 环不够分
- 移除恐惧：恐惧这一块已有坚定之心和英雄类加值
- 欢悦狂喜：是解除状态，不是预先挂的增益，而且是高环
- 优雅：迅捷、按回合算，不适合放进 Normal
- 火腹：火焰抗力盖不过已经在的防护火焰
- 勇气与生命祝福：士气加值盖不过高等英雄术和英雄祈唤，而且每人一发
- 英雄术：低级士气加值。高等英雄术和英雄祈唤还在，会盖掉它

留下三条。高等隐形只给 2805，用他那 1 个 4 环。变巨术只给 2805，一发 1 环。群体枭之智慧全队，范围是盟友，按一发来用，补的是力量、体质、魅力群体加值里没有的感知。

三种注血仍在 Quick。现在一共 77 条。游戏当时没有在运行。备份是 `bi2tl-7ea3d466491c4249aec2742271c2e71a.json.bak-20260927-2207`。校验和是 `20B40A707122B52E680ED4647FF699F75825943DBFACE5200E85EA96F53EA73E`。

## 2026-09-27 22:16 对照休息后的一键结果

当时把 Quicksave1 当成点按钮之前、Quicksave2 当成点完之后。后来对过三次存档：Quicksave1 是休息完，Quicksave2 和 Quicksave3 都是从 Quicksave1 加的 buff。Quicksave2 是改配置之前，Quicksave3 是改完之后。点的是 Normal（Long），不是 Quick。三种注血没有放，这是对的。

这次实际打上、而且和更高的增益不叠加，所以从 Normal 拿掉 14 条：

- 法师护盾：护盾加值，骨盾已经是 +6
- 祝福术、高等英雄术：士气加值，英雄祈唤已经在全队身上
- 神恩：幸运加值，神力已经在同一个人身上
- 羽步：行动自如已经盖住困难地形
- 群体抵抗火焰：防护火焰已经在全队身上
- 致命表演，以及鼓舞勇气、迷魂、三种煽动狂怒、风暴呼唤、鼓舞伟力：女王同时只能开一条吟游表演。鼓舞英雄已经开着。迷魂和煽动狂怒（敌人）也不是预先挂的增益
- 致命表演的施法者还被记成了法术来源，空法术书，本来就不会当表演开关用

改了两条，没有删：

- 幸运与决意祝福、群体幸运与决意祝福：目标改成只有马 `55FD`。日志里这一发点到 FaN 被判定成非法目标，槽位没扣，马也没加上
- 变巨术：拿掉全队的药水来源，并关掉这一条的药水。日志里每个人的变巨药水都是 `CanTarget=false`。2805 的法术来源还留着，以后法术书里准备了才会放

没有删的：斗篷之梦、高等隐形、群体枭之智慧、火元素神怪、正义之力。这次没放是因为法术书里没准备，不是条目错了。正义之力这次其实已经在 57A6 身上。镜像术也在：FaN 和 56A0 各 8 层，2805 是 5 层。

十字军之锋和破坏武器各只准备了 1 发，所以只打到名单里的第一个人。格子多准备几发才会轮到后面的人。

现在一共 63 条。游戏当时没有在运行。校验和是 `C2310E65F53A6FB5CFFD51951A6861A155A34EA7C80CD1DD66BAC443CE60F4CA`。

## 2026-09-28 00:34 Quicksave2 和 Quicksave3 直接对比

两次都从 Quicksave1 加 buff。Quicksave3 没有多出任何增益。Quicksave2 有、Quicksave3 没有的是：

- 全队，包括马：祝福术、高等英雄术、抵抗火焰
- 除了马：羽步
- 只有 FaN：法师护盾
- 只有 57A6：神恩

法师护盾在 Quicksave3 仍是 2/2，祝福术仍是 3/3。镜像术两边一样。

幸运与决意祝福的单体是接触法术，蓝图 `BlessingOfLuckAndResolveCast`，编号 `9a7e3cd1-323d-fe34-7a6d-cce357844769`。Quicksave2 点到 FaN，被判非法目标，格子还在。Quicksave3 把唯一的 1 发用掉了，只是把接触充能挂在施法者身上，马身上没有 `BlessingOfLuckAndResolveBuff`。这一条已从 Normal 拿掉。

群体那一发 `BlessingOfLuckAndResolveMass`，编号 `462c21ce-bf78-20c4-0a87-f5e4d03e17cf`，是近距范围，会直接挂增益，目标仍只有马 `55FD`。这次没准备，所以没放。

单体接触那条已删除。现在一共 62 条。游戏没有在运行。校验和是 `746D816F8EF29DFDF2E286600D3A0E6CB2B00196B0D0A04BE3D361FCB9C75D06`。

## 2026-09-28 00:45 把没准备的法术写进 Quicksave3

Quicksave2 有、Quicksave3 没有的那几条，是同一种加值已经被更高的增益盖住，所以从一键里拿掉，不是漏放：

- 祝福术、高等英雄术：士气加值，英雄祈唤已经更高
- 法师护盾：护盾加值，骨盾更高
- 羽步：行动自如已经包含困难地形
- 抵抗火焰：防护火焰更高
- 神恩：幸运加值，神力更高

Quicksave3 的法术书改过。只改了这一档。备份是同目录的 `Quick_3.zks.bak-20260928-004500`。

| 法术 | 谁 | 做法 |
|---|---|---|
| 变巨术 `c60969e7-f264-e6d4-b84a-1499fdcf9039` | 2805 法师书 | 原来会这个法术，1 环格子是空的。第 1 个 1 环格子现在准备了它 |
| 高等隐形 `ecaa0def-35b3-8f94-9bd1-976a6c9539e0` | 2805 法师书 | 唯一的 4 环格子原来是空的，现在准备了它 |
| 群体枭之智慧 `9f5ada58-1af3-db44-19b5-4db77f44e430` | 57A6 | 法术列表里有，没有 6 环格子。加了 1 个可用的 6 环格子 |
| 神怪术 `07b608fa-b304-f894-8808-98dc0764e6e5` | 57A6 | 火元素神怪是这个法术的形态。原来没有 5 环格子。加了 1 个可用的 5 环格子，准备的是神怪术 |

斗篷之梦 `7f71a70d-822a-f944-58dc-1a235507e972` 已经在 56A0 的吟游诗人法术书里，5 环，Quicksave3 里还剩 7 发。没有再往法术书里加。它是自身光环，用来影响周围的敌人。

## 2026-09-28 01:05 拿掉 Enlarge Person

Enlarge Person 只能对活着的类人生物使用。骷髅射手是亡灵，一键日志是 CanTarget=false，格子没有花掉。已从 Normal 删除。Quicksave1 和 Quicksave2 里那个 1 环准备也清成空格子。法术还在已知列表里。现在一共 61 条。

## 2026-09-28 01:08 这一轮之后

Quicksave1 是休息档，Quicksave2 是一键之后。Enlarge Person 没有再出现。Invisibility, Greater、Owl's Wisdom, Mass、Geniekind 都挂上了。英雄祈唤也在。

Cloak of Dreams 从 Normal 拿掉。它是自身光环，5 英尺内的活物每回合要做意志豁免，否则睡着。马是队里唯一的活人，站在女王旁边会被卷进去。

Blessing of Luck and Resolve, Mass 这次没放，是因为法术书里没准备。已经补进 Quicksave1 和 Quicksave2 的 6 环。目标仍只有马。

2805 的 Mirror Image 改从法师书的空 2 环格子准备。现在一共 60 条。

## 2026-09-28 01:20 按结果红字改目标

格子不够时，目标名单收成实际打得到的人，红字就不会再报 no available caster。

- Deny Death：拿掉马。7 发正好给 7 个亡灵。
- Shield of Faith：只给 Ciar、Staunton Vhane、Kestoglyr。准备了 3 发。
- Crusader's Edge：只给 Ciar。准备了 1 发。
- Disrupting Weapon：只给 FaN。准备了 1 发。
- Owl's Wisdom, Mass 和 Blessing of Luck and Resolve, Mass 从一键拿掉。战斗祭司没有可用的 6 环格子。后加的那一发点出去之后格子消失，马身上没有增益。

现在一共 58 条。


## 2026-09-28 01:56

Vampiric Shadow Shield 从 Normal 拿掉。持续时间按回合算，点完一键再存档时增益已经没了，5 环格子白花。

Deny Death 仍是近距、单人。这一轮 7 发里 Ciar、Queen Galfrey、Delamere、Kestoglyr、Skeletal Marksman、FaN 有，Staunton Vhane 没有。目标名单里还留着他，下一轮人站近就会打到。

现在一共 57 条。


## 2026-09-28 02:47

Vampiric Shadow Shield 加回 Normal，只给 FaN。持续时间 1 round/level，施法者等级 20 是 20 回合。


## 2026-09-28 02:51

Vampiric Shadow Shield 再次从 Normal 拿掉。加回去之后又测了一轮：5 环少了 1 发，FaN 身上没有增益。存档离点按钮大约 10 秒，短于 20 回合。一键施放没有把增益留下。

Deny Death 这一轮 Staunton Vhane 有，FaN 自己没有。目标名单不改。


## 2026-09-28 03:18

Vampiric Shadow Shield 按要求加回 Normal，只给 FaN。
