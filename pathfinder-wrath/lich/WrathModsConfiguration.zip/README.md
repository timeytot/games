# Wrath mod configuration notes

These files are notes and config copies. The game does not read this zip.

| File | What it is |
|---|---|
| `BuffIt-OneClickBuff.md` | Buff It 2 The Limit file layout, unit ids, and the current buff rows |
| `buffit-current-config.json` | Copy of the live Buff It config for FaN's save |
| `WrathTactics.md` | Wrath Tactics file layout, numeric enums, spell keys, and FaN's rules |
| `tactics-current-config.json` | Copy of the live Wrath Tactics config for FaN's save |

Live files stay in the game mod folders:

```
D:\SteamLibrary\steamapps\common\Pathfinder Second Adventure\Mods\WrathTactics\UserSettings\tactics-7ea3d466491c4249aec2742271c2e71a.json
D:\SteamLibrary\steamapps\common\Pathfinder Second Adventure\Mods\BuffIt2TheLimit\UserSettings\bi2tl-7ea3d466491c4249aec2742271c2e71a.json
```

The notes and filenames are English. The current decision is the last section of `WrathTactics.md`.
